﻿using BSolutions.Buttonboard.Services.Settings;
using MQTTnet;
using MQTTnet.Client;
using MQTTnet.Client.Options;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace BSolutions.Buttonboard.Services.MqttClients
{
    public class ButtonboardMqttClient : IButtonboardMqttClient, IDisposable
    {
        protected readonly ISettingsProvider _settings;
        protected readonly IMqttClient _mqttClient;
        protected readonly IMqttClientOptions _mqttClientOptions;

        private bool disposed = false;

        #region --- Constructor ---.

        public ButtonboardMqttClient(ISettingsProvider settingsProvider)
        {
            this._settings = settingsProvider;

            // MQTT Connection
            MqttFactory factory = new MqttFactory();
            this._mqttClient = factory.CreateMqttClient();
            
        }

        ~ButtonboardMqttClient()
        {
            Dispose(false);
        }

        #endregion

        public async Task ConnectAsync()
        {
            var options = new MqttClientOptionsBuilder()
                .WithTcpServer(this._settings.Mqtt.Server, this._settings.Mqtt.Port)
                .Build();

            await this._mqttClient.ConnectAsync(options, CancellationToken.None);
        }

        public async Task PublishAsync(string topic, string payload)
        {
            var message = new MqttApplicationMessageBuilder()
                .WithTopic(topic)
                .WithPayload(payload)
                .Build();

            await this.ConnectAsync();
            await this._mqttClient.PublishAsync(message, CancellationToken.None);
            await this._mqttClient.DisconnectAsync();
        }

        #region --- IDisposable ---

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                // if this is a dispose call dispose on all state you
                // hold, and take yourself off the Finalization queue.
                if (disposing)
                {
                    if (this._mqttClient != null)
                    {
                        this._mqttClient.Dispose();
                    }
                }

                this.disposed = true;
            }
        }

        #endregion
    }
}
